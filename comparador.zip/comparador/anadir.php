<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['username'] !== 'administrador') {
    echo "La sesión no esta bien";
    echo ($_SESSION['loggedin']) ;
    echo  $_SESSION['username'];
    //header("Location: login.php");
    exit;
}


?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Añadir Personaje</title>
    <link rel="stylesheet" href="estilosAnadir.css">
</head>
<body>
    <h2>Añadir Personaje</h2>
    <form id="anadirPersonaje" action="subidaPersonaje.php" method="post" enctype="multipart/form-data">
        <label for="nombre">Nombre:</label><br>
        <input type="text" id="nombre" name="nombre" required><br>
        <label for="Posicion">Posicion:</label><br>
        <input type="text" id="posicion" name="posicion" required><br>
        <label for="Goles">Goles:</label><br>
        <input type="text" id="goles" name="goles" required><br>
        <label for="Equipo">Equipo:</label><br>
        <input type="text" id="Equipo" name="Equipo" required><br>
        <label for="Edad">Edad:</label><br>
        <input type="text" id="Edad" name="Edad" required><br>
        <label for="imagen">Imagen (seleccionar enlace de Pinterest):</label><br>
        <input type="text" id="imagen_link" name="imagen_link" placeholder="Enlace de Pinterest"><br><br>
        <input type="submit" value="Agregar Personaje">
         
    </form>

    
    <script>
        document.getElementById('anadirPersonaje').addEventListener('submit', function(event) {
            // Obtener valor de los campos de imagen
            var imageUrl = document.getElementById('imagen_link').value;

            // Validar si se proporciona al menos una imagen
            if ( !imageUrl) {
                alert('Por favor, selecciona una imagen o proporciona un enlace de Pinterest.');
                event.preventDefault(); // Evitar que se envíe el formulario
            }
        });
    </script>