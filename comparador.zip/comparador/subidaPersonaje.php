<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['username'] !== 'administrador') {

    header("Location: login.php");
    exit;
}

$servidor = "localhost";
$usuario = "root";
$contra = "root1234";
$baseDeDatos = "futbolistas";
$puerto = "3360";

$conn = new mysqli($servidor, $usuario, $contra, $baseDeDatos, $puerto);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$nombre = $_POST['nombre'];
$posicion = $_POST['posicion']; 
$goles = $_POST['goles']; 
$equipo = $_POST['Equipo']; 
$edad = $_POST['Edad']; 
$foto = "";

if (!empty($_POST['imagen_link'])) {
    $foto = $_POST['imagen_link'];
} 
$nuevoFutbolista = "INSERT INTO Futbolistas (nombre, posicion, goles, equipo, edad, foto) 
                        VALUES ('$nombre', '$posicion', '$goles', '$equipo', '$edad', '$foto')";

if ($conn->query($nuevoFutbolista) === TRUE) {
    header("Location: index.php"); 
    exit;
} else {
    echo "Error al añadir futbolista: " . $conn->error;
}

$conn->close();
?>
