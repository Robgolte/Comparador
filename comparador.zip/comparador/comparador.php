<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}


$servidor = "localhost";
$usuario = "root";
$contra = "root1234";
$baseDeDatos = "futbolistas";
$puerto = "3360";


$conn = new mysqli($servidor, $usuario, $contra, $baseDeDatos, $puerto);


if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$personajes = "SELECT id_futbolista, nombre FROM futbolistas";
$todosPersonajes = $conn->query($personajes);

$personaje1 = null;
$personaje2 = null; 

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $idpersonaje1 = $_POST['personaje1'];
    $idpersonaje2 = $_POST['personaje2'];

    // personaje 1
    $personaje1BD = "SELECT * FROM futbolistas WHERE id_futbolista = $idpersonaje1";
    $personaje1FIN = $conn->query($personaje1BD);
    if ($personaje1FIN && $personaje1FIN->num_rows > 0) {
        $personaje1 = $personaje1FIN->fetch_assoc();
    }

    // personaje 2
    $personaje2BD = "SELECT * FROM futbolistas WHERE id_futbolista = $idpersonaje2";
    $personaje2FIN = $conn->query($personaje2BD);
    if ($personaje2FIN && $personaje2FIN->num_rows > 0) {
        $personaje2 = $personaje2FIN->fetch_assoc();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Comparador de Personajes</title>
    <link rel="stylesheet" href="estilosComparador.css">
</head>
<body>

<h2>COMPARADOR</h2>
<form method="post">
    <div class = "menu">
       <div >
     <h3>Selecciona un personaje :</h3>
    <label class="labelper1" for="personaje1">Personaje 1:</label>
     <select name="personaje1" id="personaje1">
                <?php
                if ($todosPersonajes->num_rows > 0) {
                    while ($row = $todosPersonajes->fetch_assoc()) {
                        $selected = ($personaje1 && $personaje1['id_futbolista'] == $row['id_futbolista']) ? "selected" : "";
                        echo "<option value='" . $row['id_futbolista'] . "' $selected>" . $row['nombre'] . "</option>";
                    }
                } 
                ?>
    </select>
        </div>

        <div>
            <h3>Selecciona un personaje :</h3>
            <label class="labelper2" for="personaje2">Personaje 2:</label>
            <select name="personaje2" id="personaje2">
                <?php
                $todosPersonajes->data_seek(0);
                if ($todosPersonajes->num_rows > 0) {
                    while ($row = $todosPersonajes->fetch_assoc()) {
                        $selected = ($personaje2 && $personaje2['id_futbolista'] == $row['id_futbolista']) ? "selected" : "";
                        echo "<option value='" . $row['id_futbolista'] . "' $selected>" . $row['nombre'] . "</option>";
                    }
                }
                ?>
            </select>
        </div>
    </div>
    
    <div class = "btnComparar">
        <input type="submit" name="submit" value="Comparar">
    </div>
</form>




<?php
 if ($personaje1 && $personaje2) :
 ?>
    <table>
        <tr>
            <th>FUTBOLISTA 1 </th>
            <th>FUTBOLISTA 2  </th>
        </tr>
        <tr>
            <td>Nombre: <?php echo $personaje1['nombre']; ?></td>
            <td>Nombre: <?php echo $personaje2['nombre']; ?></td>
        </tr>
        <tr>
            <td>Posicion: <?php echo $personaje1['posicion']; ?></td>
            <td>Posicion: <?php echo $personaje2['posicion']; ?></td>
        </tr>
        <tr>
            <td>Goles: <?php echo $personaje1['goles']; ?></td>
            <td>Goles: <?php echo $personaje2['goles']; ?></td>
        </tr>
        <tr>
            <td>Equipo: <?php echo $personaje1['equipo']; ?></td>
            <td>Equipo: <?php echo $personaje2['equipo']; ?></td>
        </tr>
        <tr>
            <td>Edad: <?php echo $personaje1['edad']; ?></td>
            <td>Edad: <?php echo $personaje2['edad']; ?></td>
        </tr>
        <tr>
            <td><img src="<?php echo $personaje1['foto']; ?>" alt=></td>
            <td><img src="<?php echo $personaje2['foto']; ?>" alt=></td>
        </tr>

</table>
</body>

<?php endif; ?>
        

