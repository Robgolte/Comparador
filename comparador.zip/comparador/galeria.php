<?php
// Conexión a la base de datos
$servidor = "localhost";
$usuario = "root";
$contra = "root1234";
$baseDeDatos = "futbolistas";
$puerto = "3360";

// Crear conexión
$conn = new mysqli($servidor, $usuario, $contra, $baseDeDatos, $puerto);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$personajes = "SELECT nombre, foto FROM futbolistas";
$ftperosonajes = $conn->query($personajes);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="estilosIndex.css">
    <h1>GALERIA DE IMAGENES </h1>
</head>
<body>
    <a href="login.php" class="login-btn">Iniciar Sesión</a>
    <div class="gallery">
        <?php
        if ($ftperosonajes->num_rows > 0) {
            while ($row = $ftperosonajes->fetch_assoc()) {
                echo "<div class='gallery-item'>";
                echo "<img src='" . $row['foto'] . "' alt='" . $row['nombre'] . "'>";
                echo "<p>" . $row['nombre'] . "</p>";
                echo "</div>";
            }
        } else {
            echo "No hay personajes disponibles.";
        }
        ?>
    </div>
</body>
</html>
