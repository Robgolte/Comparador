<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Inicio - Temática Fútbol</title>
   <link rel="stylesheet" href="estilosPrincipal.css">
</head>
<body>
    <div class="black-bar">
        <h1>COMPARADOR DE FUTBOLISTAS</h1>
        <nav>
            <ul>
                <li><a href="login.php" class="boton">Añadir Personaje</a></li>
                <li><a href="galeria.php" class="boton">Galería</a></li>
                <li><a href="login.php" class="boton">Comparador</a></li> <!-- Nuevo botón "Comparador" -->
                <li><a href="login.php" class="boton iniciar-sesion"><img src="img/iniciosesion.png" alt=""></a></li> <!-- Moví el botón de "Iniciar Sesión" aquí -->        
            </ul>
        </nav>
    </div>

    <div id="fondo">
        <div class="tematica-futbol lado-izquierdo"></div> <!-- Elemento temático de fútbol en el lado izquierdo -->
       <img src="img/bernabeu1.png" alt=""><!-- Imagen central -->
        <div class="tematica-futbol lado-derecho"></div> <!-- Elemento temático de fútbol en el lado derecho -->
    </div>

    <footer id="footer">
        <p><b>Comparador de Futbolistas</b></p>
        <p><a href="index.php">Volver a inicio</a></p> <!-- Corrección del cierre de la etiqueta del enlace -->
    </footer>

</body>
</html>