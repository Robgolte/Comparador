<?php
session_start();

// Verificar si el formulario ha sido enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar las credenciales del usuario
    if ($_POST['username'] === 'ruben' && $_POST['password'] === 'romero') {
        
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = 'ruben';
        header("Location: comparador.php");
        
    } 
    elseif ($_POST['username'] === 'administrador' && $_POST['password'] === '1234') {
        // Iniciar sesión para el usuario "admin"
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = 'administrador';
        header("Location: anadir.php");
    }
    else {
        // Credenciales incorrectas
        $error_message = "Sesion no iniciada . Inténtalo de nuevo.";
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="estilosLogin.css">
</head>


<body>

<h2>Iniciar Sesión</h2>

<div class= "login">
<form action="login.php" method="post">
    <label for="username">Usuario:</label><br>
    <input type="text" id="username" name="username" required><br>
    <label for="password">Contraseña:</label><br>
    <input type="password" id="password" name="password" required><br><br>
    <input type="submit" value="Iniciar Sesión">
</form>
</div>
</body>
</html>
